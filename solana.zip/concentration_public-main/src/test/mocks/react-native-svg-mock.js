module.exports = 'SvgMock'
module.exports.ReactComponent = 'SvgMock'
